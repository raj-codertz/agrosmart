## 2023 YOUTH CODING HACKATHON

**Team Name:** Shadow

**Track:** Track 2 Agriculture

Name | Github Username | 
--- | --- | 
Turbin Alphone | [TurbinAlp](https://github.com/TurbinAlp) | 
Martha Bubelwa | [Abella0987](https://github.com/Abella0987) | 
Danford Chriss | [386-Virus](https://github.com/386-Virus) | 
Rajab Shabani | [raj-codertz](https://github.com/raj-codertz) | 
Amonenengha Mpinguhi | [Nengha-John](https://github.com/Nengha-John) | 

