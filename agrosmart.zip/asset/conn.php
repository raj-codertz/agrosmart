<?php
    $servername = "sql101.epizy.com";
    $dbuser = "epiz_34096657";
    $dbpassword = "Agrosmart.2023";
    $dbname = "epiz_34096657_agrosmart";

    $conection = mysqli_connect($servername, $dbuser, $dbpassword, $dbname);

?>